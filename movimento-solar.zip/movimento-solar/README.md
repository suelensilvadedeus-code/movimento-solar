# ☀️ Movimento Solar - Irradiância Solar
Simulador interativo desenvolvido por **Suélen Silva**.

## 🚀 Como usar:
1. Envie o arquivo CSV unificado contendo as medições.
2. Escolha até 4 regiões.
3. Visualize a animação com o movimento solar.
4. Baixe o GIF gerado.
5. Compartilhe o simulador via QR Code.

## 🌐 Link do aplicativo:
https://movimento-solar.streamlit.app

## 💻 Publicação no Streamlit Cloud:
1. Crie um repositório no GitHub com o nome `movimento-solar`
2. Envie este arquivo + `requirements.txt` + `movimento_solar_web.py`
3. Implante o app no [Streamlit Cloud](https://share.streamlit.io)

---
Desenvolvido por **Suélen Silva** © 2025
